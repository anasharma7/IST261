package sumcalculatorfixme;

public class Controller {

    private final Model model;
    private final View view;

    public Controller() {
        model = new Model();
        view = new View(this);
    }

    public String computeSum(String nums) {
       Boolean test = true;
       int len = nums.length();
      for (int i = 0; i < len; i++) {
         // checks whether the character is not a digit and not a space
            if ((Character.isDigit(nums.charAt(i)) == false) && (nums.charAt(i) != ' ')) {
            test = false; // if it is not any of them then it returns false
            view.showErrorMsg("Only numbers 0-99 are valid");
         }
      }
      
   
       if( test == true){
        String[] numbersSplit = nums.split("\\s+");
        for (String str : numbersSplit){
             int number = Integer.parseInt(str);
            if(number <= 0 || number >= 99){
                view.showErrorMsg("Only numbers 0-99 are valid");
                return "";
            }
        }
        return model.computeSum(nums);
    }
       return "";
    }


    public View getView() {
        return view;
    }

}
