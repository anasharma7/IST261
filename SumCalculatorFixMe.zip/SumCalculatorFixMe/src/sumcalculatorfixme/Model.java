package sumcalculatorfixme;

public class Model {

    private int sum;

    public Model() {
        sum = 0;
    }
//  CHANGE THIS METHOD
// DATA VALIDATION

    public String computeSum(String numbers) {
        sum = 0;
        String[] numbersResult = numbers.split("\\s+");
        for (String str : numbersResult) {
            sum += Integer.parseInt(str);

        }
        return sum + "";
    }

}
