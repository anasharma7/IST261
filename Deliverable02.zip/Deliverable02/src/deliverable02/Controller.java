/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package deliverable02;

/**
 *
 * @author anasharma
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Controller {

    private final Model model; 
    private final View view;

    public Controller() {
        model = new Model();
        view = new View(this);
    }

    
    public String doLotteryDrawings(String userNums, String numDrawings) {
        String result = "";
        Set<Integer> lottoResults = new HashSet<>();
        int count = 0;
        int intDrawings = Integer.parseInt(numDrawings);
        String output = "You entered: " + userNums + "/n";
        String drawing = "";
        if (userNumIsValid(userNums)) {
            if (numDrawingsIsValid(numDrawings)) {
                while (count < intDrawings) {
                    //assuming data is valid; run lotto
                    List<Integer> newLottoResults = new ArrayList<>();
                    lottoResults = model.doOneDrawing();
                    newLottoResults.addAll(lottoResults);
                    result = findMatches(userNums, lottoResults);
                    count++;
                    drawing = drawing + "Drawing " + count + " lotto numbers" + " are " + lottoResults +", which match these numbers: " + findMatches(userNums, lottoResults) + "\n"; 
                }
            }
        }
        return drawing;
    }

    public String findMatches(String nums, Set<Integer> lottoResults) {
        List<Integer> result = new ArrayList<>();
        List<Integer> numsList
                = Arrays.stream(nums.split("\\s+")).map(Integer::parseInt)
                        .collect(Collectors.toList());
        for (Integer temp : lottoResults) {
            if (numsList.contains(temp)) {
                result.add(temp);
            }
        }
        return result.toString();
    }

    public View getView() {
        return view;
    }

    public boolean numDrawingsIsValid(String numDrawings) {
        Integer intDrawings = Integer.valueOf(numDrawings);
        if (intDrawings < 1 || intDrawings > 10) {
            view.showErrorMsg("Numbers must be between 1 through 10", intDrawings);
            return false;
        } else {
            return true;
        }
    }

    public boolean userNumIsValid(String userNums) {
        System.out.println(userNums);

        //checks if there are 6 numbers separated by one or more whitespaces
        if (userNums.matches("\\d{1,2}\\s+\\d{1,2}\\s+\\d{1,2}\\s+\\d{1,2}\\s+"
                + "\\d{1,2}\\s+\\d{1,2}")) {
            //checks if the numbes are between 1 through 60
            String[] nums = userNums.split("\\s+");
            for (String num : nums) {
                int n = Integer.parseInt(num);
                if (n < 1 || n > 60) {
                    view.showErrorMsg("Numbers must be between 1 through 60", 1);
                    return false;
                }
            }
            return true;
        } else {
            view.showErrorMsg("Enter SIX numbers separated by ONE OR MORE white spaces", 1);
            return false;
        }
    }

}
