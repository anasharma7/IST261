/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package deliverable02;

/**
 *
 * @author anasharma
 */

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class Model {

    private final Set<Integer> results;

    public Model() {
        this.results = new HashSet<>();
    }

    public Set<Integer> doOneDrawing() {
        //clears the results array when drawing another set of numbers
        results.clear();

        //https://stackoverflow.com/questions/4040001/creating-random-numbers-with-no-duplicates
        //Sets will automatically check for duplicate random numbers
        Random rng = new Random();
        Set<Integer> generated = new HashSet<>();
        while (generated.size() < 6) {
            Integer next = rng.nextInt(60) + 1;
            generated.add(next);
        }
        return generated;
    }
}
