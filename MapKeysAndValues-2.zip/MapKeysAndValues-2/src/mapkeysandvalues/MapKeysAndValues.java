package mapkeysandvalues;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class MapKeysAndValues {

    final static String filePath
            = "C:\\Users\\Ana\\Desktop\\IST261\\MapKeysAndValues\\MapKeysAndValues\\StudentGpaMap.txt";

    public static void main(String[] args) throws FileNotFoundException {
        // read data values from StudentGpaMap.txt file into studentGpaMap
        Map<String, Double> map
                = new HashMap<>();
        BufferedReader fileRead = null;
        try {
            File file = new File(filePath);
            fileRead = new BufferedReader(new FileReader(file));

            String line = null;
            while ((line = fileRead.readLine()) != null) {

                String[] parts = line.split(" ");
                String name = parts[0];
                String gpa = parts[1];
                Double gpaFinal = Double.valueOf(gpa);

                if (!name.equals("") && !gpa.equals("")) {
                    map.put(name, gpaFinal);
                }
            }
           

        } catch (IOException | NumberFormatException e) {
        } finally {

            // Always close the BufferedReader
            if (fileRead != null) {
                try {
                    fileRead.close();
                } catch (IOException e) {
                }
            }
        }
        printKeyValuePairs(map);
    }

    private static void printKeyValuePairs(Map<String, Double> map) {
        // using for loop and Map.Entry
        System.out.println("\nkey-value pairs using for loop and Map.Entry");
        for (Map.Entry<String, Double> pair : map.entrySet()) {
            System.out.println("key = " + pair.getKey() + ", value = " + pair.getValue());
        }

        // using lambda expression with two parameters (one for keys and one for values) and map.foreach
        System.out.println("\nkey-value pairs using lambda expression and .foreach()");
        map.forEach((key, value) -> {
            System.out.println("Key = " + key + ", Value = " + value);
        });

        // using Iterator of an appropriate type and while loop
        System.out.println("\nkey-value pairs using Iterator of appropriate type and while loop");
        Iterator<Map.Entry<String, Double>> it = map.entrySet().iterator();
        while (it.hasNext()) {
             Map.Entry entryVar = (Map.Entry)it.next();
            System.out.println("Key = " + entryVar.getKey() + ", Value = " + entryVar.getValue());
        }
//        Iterator mapIter = map.iterator();
//        while(mapIter.hasNext()){
//            Map.Entry entryVar = (Map.Entry)mapIter.next();
//            System.out.println("Key = " + entryVar.getKey() + ", Value = " + entryVar.getValue());
//        }
        // using streams
        // https://stackoverflow.com/questions/46898/how-do-i-efficiently-iterate-over-each-entry-in-a-java-map
        // See summary post, item #7, modify appropriately
        System.out.println("\nkey-value pairs using streams");
        map.entrySet().stream().forEach(e -> System.out.println("Key = " + e.getKey() + ", Value = " + e.getValue()));
        //look at number 7 on link

    }
}
