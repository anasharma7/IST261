package duplicatechecker;

import java.util.Arrays;
import java.util.List;
import java.util.HashSet;

public class DuplicateChecker {

    public static void main(String[] args) {
        List<Integer> listOfIntegers = Arrays.asList(1, 2, 3, 4, 2, 6);
        System.out.println(hasDuplicateIntegers(listOfIntegers));
    }

    static boolean hasDuplicateIntegers(List<Integer> numList) {
	HashSet<Integer> set = new HashSet<Integer>();
	for (int i = 0; i < numList.size(); i++) {
        if (set.contains(numList.get(i))) {
            return true;
        } else {
            set.add(numList.get(i));
        }
    }   
	return false;
	}
}
