import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;



public class LocationGraph {
    private Map<String, Location> vertices;

    public LocationGraph() {
        vertices = new HashMap<>();
    }

    public boolean AddLocation(String location){
        Location vertex = new Location(location);
        if(vertices.containsValue(vertex)){
            System.out.println("Location already exists! Unable to add location");
            return false;
        }else{
            vertices.put(location, vertex);
            return true;
        }
    }

    public boolean AddDistance(String locationA, String locationB, Double distance){
        if(!vertices.containsKey(locationA) ){
            AddLocation(locationA);
        }
        if(!vertices.containsKey(locationB)) {
            AddLocation(locationB);
        }
        if(vertices.get(locationA).hasEdge(vertices.get(locationB)) || vertices.get(locationB).hasEdge(vertices.get(locationA))){
            System.out.println("Connection between the locations already exists!");
            return false;
        }else{
            vertices.get(locationA).addEdge(new Distance(vertices.get(locationB), distance));
            vertices.get(locationB).addEdge(new Distance(vertices.get(locationA), distance));
            return true;
        }
    }

    
    public Double findDistanceBF(String locationA, String locationB){
        Map<String, Boolean> visited = new HashMap<>();
        for (Location l : vertices.values()) {
            visited.put(l.getLabel(), false);
        }
        LinkedList<String> queue = new LinkedList<String>();
        double total = 0;

        visited.replace(locationA, true);
        queue.add(locationA);

        while(queue.size() != 0){
            locationA = queue.poll();
            System.out.println(locationA + " ");

            Iterator<Distance> i = vertices.get(locationA).getEdges().listIterator();
            while(i.hasNext()){
                Distance next = i.next();
                if(next.getvertex().getLabel().equals(locationB)){
                    total = total + next.getWeight();
                    return total;
                }
                else if(visited.get(next.getvertex().getLabel()) == false ||
                visited.get(next.getvertex().getLabel()) == null ){
                    total = total + next.getWeight();
                    visited.replace(next.getvertex().getLabel(), true);
                    queue.add(next.getvertex().getLabel());
                }
            }
        }
        System.out.println("A path couldnot be established");   
        return null;
    }

    
    public Double DFUtil(String locationA, String locationB, Map<String, Boolean> visited){
        visited.replace(locationA, true);
        System.out.println(locationA + " ");
        double total = 0;

        Iterator<Distance> i = vertices.get(locationA).getEdges().listIterator();
        while(i.hasNext()){
            Distance next = i.next();
            if (next.getvertex().getLabel().equals(locationB)) {
                total = total + next.getWeight();
                return total;
            }
            else if(visited.get(next.getvertex().getLabel()) == false || 
            visited.get(next.getvertex().getLabel()) == null){
                total = total + next.getWeight();
                DFUtil(next.getvertex().getLabel(), locationB, visited);
            }
        }
        System.out.println("A path couldnot be established");
        return null;
    }
    
    public double findDistanceDF(String locationA, String locationB){
        Map<String, Boolean> visited = new HashMap<>();
        for (Location l : vertices.values()) {
            visited.put(l.getLabel(), false);
        }
        return DFUtil(locationA, locationB, visited);
    }


    public boolean detectcycleutil(String start, Map<String, Boolean> visited, String parent){
        visited.replace(start, true);
        String s;
        Iterator<Distance> i = vertices.get(start).getEdges().listIterator();
        while(i.hasNext()){
            s = i.next().getvertex().getLabel();
            if(visited.get(s) == false){
                if(detectcycleutil(s, visited, start)){
                    return true;
                }
            }else if(!(s.equals(parent))){
                return true;
            }
        }
        return false;
    }

    public boolean detectcycle(){

        Map<String, Boolean> visited = new HashMap<>();
        for(Location l : vertices.values()){
            visited.put(l.getLabel(), false);
        }

        for(Location l : vertices.values()){
            if(visited.get(l.getLabel()) == false){
                if(detectcycleutil(l.getLabel(), visited, "placeholder")){
                    return true;
                }
            }
        }
        return false;    
    }
    
    public void addEdge(Distance edge) {
        Location vertex = edge.getvertex();

        if (!vertices.containsValue(vertex)) {
            throw new IllegalArgumentException("Vertex does not exist.");
        }
        vertex.addEdge(edge);
    }

    public void removeVertex(String label) {
        Location removedVertex = vertices.remove(label);
        if (removedVertex != null) {
            removedVertex.getEdges().forEach(edge -> {
                Location connectedVertex = edge.getConnectedVertex(removedVertex);
                connectedVertex.removeEdge(edge);
            });
        }
    }

    public void removeEdge(String label1, String label2) {
        Location vertex1 = vertices.get(label1);
        Location vertex2 = vertices.get(label2);
        if (vertex1 == null || vertex2 == null) {
            throw new IllegalArgumentException("One or both vertices do not exist.");
        }
        Distance edgeToRemove = vertex1.getEdges().stream()
                .filter(edge -> edge.isConnectedTo(vertex2))
                .findFirst()
                .orElse(null);
        if (edgeToRemove != null) {
            vertex1.removeEdge(edgeToRemove);
            vertex2.removeEdge(edgeToRemove);
        }
    }

    public List<Location> getVertices() {
        return new ArrayList<>(vertices.values());
    }

    public Location getVertex(String label) {
        return vertices.get(label);
    }

    public int getIndex(Location vertex) {
        int index = -1;
        int i = 0;
        for (Location v : vertices.values()) {
            if (v.equals(vertex)) {
                index = i;
                break;
            }
            i++;
        }
        return index;
    }
}
