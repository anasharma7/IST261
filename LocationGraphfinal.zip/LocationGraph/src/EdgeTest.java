/*import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class EdgeTest {
    @Test
    public void testGetFrom() {
        Vertex from = new Vertex("A");
        Vertex to = new Vertex("B");
        Edge edge = new Edge(from, to, 10.0);

        assertEquals(from, edge.getFrom());
    }

    @Test
    public void testGetTo() {
        Vertex from = new Vertex("A");
        Vertex to = new Vertex("B");
        Edge edge = new Edge(from, to, 10.0);

        assertEquals(to, edge.getTo());
    }

    @Test
    public void testGetWeight() {
        Vertex from = new Vertex("A");
        Vertex to = new Vertex("B");
        Edge edge = new Edge(from, to, 10.0);

        assertEquals(10.0, edge.getWeight(), 0.0);
    }

    @Test
    public void testSetWeight() {
        Vertex from = new Vertex("A");
        Vertex to = new Vertex("B");
        Edge edge = new Edge(from, to, 10.0);


        double newWeight = 15.0;
        edge.setWeight(newWeight);

        assertEquals(newWeight, edge.getWeight(), 0.0);
    }
}*/
