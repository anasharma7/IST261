package deliverableone;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Controller {

    private final Model model; 
    private final View view;

    public Controller() {
        model = new Model();
        view = new View(this);
    }

    
    public String doLotteryDrawings(String userNums, String numDrawings) {
        Set<Integer> lottoResults = new HashSet<>();
        int count = 0;
        boolean check = true;
        check = numDrawingsIsValid(numDrawings);
        String output = "You entered: " + userNums ;
        List<List<Integer>> listOLists = new ArrayList<>();
        if (userNumIsValid(userNums) && check) {
            
                int intDrawings = Integer.parseInt(numDrawings);
                while (count < intDrawings) {
                    List<Integer> newLottoResults = new ArrayList<>();
                    lottoResults = model.doOneDrawing();
                    newLottoResults.addAll(lottoResults);
                    
                    count++;
                    listOLists.add(findMatches(userNums,lottoResults));
                    
                }
            
        }else{
            return "";
        }
        return output + "\n" + countMatches(listOLists);
    }

    public List<Integer> findMatches(String nums, Set<Integer> lottoResults) {
        List<Integer> result = new ArrayList<>();
        List<Integer> numsList
                = Arrays.stream(nums.split("\\s+")).map(Integer::parseInt)
                        .collect(Collectors.toList());
        for (Integer temp : lottoResults) {
            if (numsList.contains(temp)) {
                result.add(temp);
            }
        }
        
        return result;
    }
public String countMatches(List<List<Integer>> matches) {
    int count0 = 0;
    int count1 = 0;
    int count2 = 0;
    int count3 = 0;
    int count4 = 0;
    int count5 = 0;
    int count6 = 0;
    for(int i= 0; i < matches.size();i++){
       switch(matches.get(i).size()) {
           case 0 -> count0++;
           case 1 -> count1++;
           case 2 -> count2++;
           case 3 -> count3++;
           case 4 -> count4++;
           case 5 -> count5++;
           case 6 -> count6++;
       }
    }
    
    return count0 + " drawings matched 0 of your numbers.\n" +
            count1 + " drawings matched 1 of your numbers.\n" +
            count2 + " drawings matched 2 of your numbers.\n" +
            count3 + " drawings matched 3 of your numbers.\n" +
            count4 + " drawings matched 4 of your numbers.\n" +
            count5 + " drawings matched 5 of your numbers.\n" +
            count6 + " drawings matched 6 of your numbers.\n" ;
}
    public View getView() {
        return view;
    }

    public boolean numDrawingsIsValid(String numDrawings) {
        
     
        if(numDrawings.isBlank()){
                        view.showErrorMsg("Please enter number of drawings");
                        return false;
        }
        if(numDrawings.matches("\\d{1,6}")){
        if( Integer.parseInt(numDrawings) <= 100000){
            return true;
        }else{
            view.showErrorMsg("Can only do up to 100000 drawings at once and enter your number with no leading or tailing white space");
            return false;
        }
    }else{
         view.showErrorMsg("enter your number of drawings with no leading or tailing white space and only digits");
            return false;   
        }
    }

    public boolean userNumIsValid(String userNums) {
        if (userNums.matches("\\d{1,2}\\s+\\d{1,2}\\s+\\d{1,2}\\s+\\d{1,2}\\s+"
                + "\\d{1,2}\\s+\\d{1,2}")) {
            //checks if the numbes are between 1 through 60
            if (userNums.matches("((60|([1-5]?[0-9]))\\s+){5}((60|([1-5]?[0-9])))")) {
                return true;
            } else {
                view.showErrorMsg("Numbers must be between 1 through 60");
            }
        } else {
            view.showErrorMsg("Enter SIX numbers separated by ONE OR MORE white spaces with no trailing or leading spaces");
        }
        return false;
    }

}
