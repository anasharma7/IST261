package deliverableone;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public final class View extends JFrame {

    private static final int FRAME_WIDTH = 850;
    private static final int FRAME_HEIGHT = 280;

    private static final int AREA_ROWS = 10;
    private static final int AREA_COLUMNS = 50;

    private static final String INPUT_USER_NUMS
            = "\nEnter exactly just six integers "
            + "from 1 through 60, "
            + "separated by one or more spaces with no leading or "
            + "trailing whitespace";

    private static final String INPUT_NUM_DRAWINGS
            = "\nEnter just an integer "
            + "from 1 through 10, "
            + "with no leading or "
            + "trailing whitespace";

    private JLabel labelUserNums;
    private JTextField textFieldUserNums;

    private JLabel labelNumDrawings;
    private JTextField textFieldNumDrawings;

    private JButton button;
    private final JTextArea resultArea;

    private final Controller cntl;

    public View(Controller controller) {
        cntl = controller;
        resultArea = new JTextArea(AREA_ROWS, AREA_COLUMNS);
        resultArea.setEditable(false);
        resultArea.setText("");

        createTextField();
        createButton();
        createPanel();

        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        setLocationRelativeTo(null); // centers frame
        setDefaultCloseOperation(EXIT_ON_CLOSE); // quits when frame closed
        //https://stackoverflow.com/questions/13731710/allowing-the-enter-key-to-press-the-submit-button-as-opposed-to-only-using-mo
        getRootPane().setDefaultButton(button);
    }

    private void createTextField() {
        labelUserNums = new JLabel(INPUT_USER_NUMS);
        final int FIELD_WIDTH = 10;
        textFieldUserNums = new JTextField(FIELD_WIDTH);

        labelNumDrawings = new JLabel(INPUT_NUM_DRAWINGS);
        textFieldNumDrawings = new JTextField(FIELD_WIDTH);
    }

    private void createButton() {
        button = new JButton("Check For Match");
        button.addActionListener(event -> showLottoResults(textFieldUserNums.getText(), textFieldNumDrawings.getText()));
    }

    private void createPanel() {
        JPanel panel = new JPanel();
        panel.add(labelUserNums);
        panel.add(textFieldUserNums);
        
        panel.add(labelNumDrawings);
        panel.add(textFieldNumDrawings);
        JScrollPane scrollPane = new JScrollPane(resultArea);
        panel.add(scrollPane);
        panel.add(button);
        add(panel);
    }

    private void showLottoResults(String input, String numDrawings) {
        resultArea.setText(cntl.doLotteryDrawings(input, numDrawings) + "\n");
    }

    public void showErrorMsg(String howToFixInputError) {
        javax.swing.JOptionPane.showMessageDialog(new javax.swing.JFrame(),
                "Invalid Input: " + textFieldUserNums.getText() + "\n"
                + howToFixInputError);
        textFieldUserNums.setText("");
        textFieldUserNums.requestFocus();
    }

    public void displaySelf() {
        this.setVisible(true);
    }
}
